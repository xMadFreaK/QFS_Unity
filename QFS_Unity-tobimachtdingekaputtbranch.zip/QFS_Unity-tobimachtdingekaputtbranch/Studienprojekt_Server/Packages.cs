﻿// Server sends out ServerPackages and listens to ClientPackages
// Client sends out ClientPackages and listens to ServerPackages

public enum ServerPackages
{

}

public enum ClientPackages
{
    CLogin = 1; // package identifier
}