﻿
namespace Studienprojekt_Server
{
    class Constants
    {
        public const int MAX_PLAYERS = 1000;
    }
}
