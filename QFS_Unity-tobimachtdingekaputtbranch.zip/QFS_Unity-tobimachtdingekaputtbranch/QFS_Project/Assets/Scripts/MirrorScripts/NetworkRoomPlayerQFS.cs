﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

// class for all players who are not in the game yet but pre-login
public class NetworkRoomPlayerQFS : NetworkBehaviour
{
    
}
