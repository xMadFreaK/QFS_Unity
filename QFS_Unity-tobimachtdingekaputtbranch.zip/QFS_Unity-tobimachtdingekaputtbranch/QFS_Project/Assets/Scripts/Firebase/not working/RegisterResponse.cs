﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class RegisterResponse
{
    public string localId;
    public string idToken;

}
